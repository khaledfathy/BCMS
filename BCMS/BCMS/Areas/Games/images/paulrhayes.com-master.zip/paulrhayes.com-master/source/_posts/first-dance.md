layout: photo
title: "End of the first dance"
date: 2013-10-26 20:09:03
flickr: https://www.flickr.com/photos/prhayes/10645079785/
500px: http://500px.com/photo/75799123/end-of-the-first-dance-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 50mm f/1.4 USM"
aperture: "ƒ/1.6"
shutter: "1/50"
iso: 500
focal: "50.0mm"

categories:
  - photography
---

The end of Frankie and Tim’s carefully choreographed first dance. I’m not a wedding photographer, the stress would be too much, but I always take my camera along to a wedding.
