layout: photo
title: "Sunbird"
date: 2014-03-26 06:59:51
flickr: https://www.flickr.com/photos/prhayes/14253143355/
instagram: http://instagram.com/p/oWwRphNFPp/
500px: http://500px.com/photo/75799133/sunbird-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/4.0"
shutter: "1/1000"
iso: 100
focal: "200.0mm"

categories:
  - photography
---

From our [trip to Kota Kinabalu, Borneo](http://www.sam-and-paul.com/2014/05/shangri-la-rasa-ria-borneo/). These pretty sunbirds flitted about the pink-flowered trees near our hotel. Almost as small as hummingbirds, they rarely stayed still long enough to focus.
