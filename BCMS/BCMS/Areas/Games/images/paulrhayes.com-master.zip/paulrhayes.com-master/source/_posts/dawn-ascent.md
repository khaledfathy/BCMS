layout: photo
title: "Dawn ascent"
date: 2014-08-09 06:46:00
flickr: https://www.flickr.com/photos/prhayes/14879645092/
500px: http://500px.com/photo/79297067/dawn-ascent-by-paul-hayes
instagram: http://instagram.com/p/riJsi2tFJ3/

exif: true
camera: "Canon EOS 70D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/5.6"
shutter: "1/1250"
iso: 100
focal: "192.0mm"

categories:
  - photography
---

Awake at 4am, and at the Bristol balloon fiesta by 6am. The weather conditions were perfect, and when the morning light peeked over the horizon 100 balloons began their ascent from Ashton Court.
