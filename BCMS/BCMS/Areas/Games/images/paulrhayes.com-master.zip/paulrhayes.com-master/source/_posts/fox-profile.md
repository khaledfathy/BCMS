layout: photo
title: "Fox prowling at dusk"
date: 2014-06-25 18:30:18
flickr: https://www.flickr.com/photos/prhayes/14517664861/
500px: http://500px.com/photo/75799137/fox-prowling-at-dusk-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/5.6"
shutter: "1/1000"
iso: 400
focal: "155.0mm"

categories:
  - photography
---

Taken at the British Wildlife Centre in Sussex, during my first wildlife photography lesson. Occasionally this fox would stoop down and look up expectantly. From my vantage point, lying in the grass, I waited for the late summer sun to catch his face.
