layout: photo
title: "Harvest mouse on wheat"
date: 2014-06-25 16:54:39
flickr: https://www.flickr.com/photos/prhayes/14724105217/
500px: http://500px.com/photo/79634811/harvest-mouse-on-wheat-by-paul-hayes
instagram: http://instagram.com/p/rr3QLztFNj/

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/5.6"
shutter: "1/2500"
iso: 800
focal: "200.0mm"

categories:
  - photography
---

In the midsummer evening, this friendly harvest mouse paused to have a look around before climbing to the top of the wheat.
