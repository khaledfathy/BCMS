layout: photo
title: "Brighton’s West Pier"
date: 2014-01-18
flickr: https://www.flickr.com/photos/prhayes/12019456376/
500px: http://500px.com/photo/75799125/brighton%E2%80%99s-west-pier-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 50mm f/1.4 USM"
aperture: "ƒ/4.5"
shutter: "1/160"
iso: 100

categories:
  - photography
---

In January the sun sets just behind Brighton’s burnt out West Pier. After a couple of days where the bitter cold and clouds didn’t reward me, eventually the conditions were just right.
