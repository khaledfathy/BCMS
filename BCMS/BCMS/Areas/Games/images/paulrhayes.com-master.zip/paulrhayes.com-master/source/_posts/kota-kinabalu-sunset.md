layout: photo
title: "Sunset in Kota Kinabalu"
date: 2014-03-23 10:52:39
flickr: https://www.flickr.com/photos/prhayes/14229790106/
instagram: http://instagram.com/p/l_k0Y-tFIG/
500px: http://500px.com/photo/75799127/sunset-in-kota-kinabalu-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/4.0"
shutter: "1/640"
iso: 100
focal: "75.0mm"

categories:
  - photography
---

From our [trip to Kota Kinabalu, Borneo](http://www.sam-and-paul.com/2014/05/shangri-la-rasa-ria-borneo/). Every night the view of sunset from out hotel was spectacular. The beach faces west for a per­fect beach­side sun­set. And every night, as the sun went down and the sky turned red, guests flocked to the sea with their expen­sive cam­eras and tripods (or iPads) to try and cap­ture it.
