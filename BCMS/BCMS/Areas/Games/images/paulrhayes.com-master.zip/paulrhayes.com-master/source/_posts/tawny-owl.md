layout: photo
title: "Tawny owl"
date: 2014-06-25 19:17:33
flickr: https://www.flickr.com/photos/prhayes/14901756036/
500px: http://500px.com/photo/79638215/tawny-owl-by-paul-hayes
instagram: http://instagram.com/p/rtx6O0NFKN/

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/5.6"
shutter: "1/160"
iso: 1600
focal: "200.0mm"

categories:
  - photography
---

Taken at the British Wildlife Centre in Sussex, during my first wildlife photography lesson. I love the brown tones of the owl’s plumage against the bark of the tree.
