layout: photo
title: "Fox at dusk"
date: 2014-06-25 18:35:10
flickr: https://www.flickr.com/photos/prhayes/14334398000/
500px: http://500px.com/photo/75799135/fox-at-dusk-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/5.6"
shutter: "1/500"
iso: 400
focal: "70.0mm"

categories:
  - photography
---

Taken whilst on a wildlife photography course in Sussex. The evening light was perfect — we couldn’t have asked for anything better. Lying down in the grass, I angled the camera upwards to capture the warm orange fur of a fox with a glowing outline.
