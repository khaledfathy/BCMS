layout: photo
title: "Lightning over Brighton station"
date: 2014-07-18 01:48:08
flickr: https://www.flickr.com/photos/prhayes/14680202454/
500px: http://500px.com/photo/77097875/lightning-over-brighton-station-by-paul-hayes
instagram: http://instagram.com/p/qpMA5hNFAo

exif: true
camera: "Canon EOS 70D"
lens: "Canon EF50mm f/1.4 USM"
aperture: "ƒ/18.0"
shutter: "30"
iso: 100
focal: "50.0mm"

categories:
  - photography
---

The storm, which [came in from the sea](/2014-07/lightning-brighton/), continued north, over the city and out to the south downs. As rain began barreling in the south facing window, I looked East to capture this with my first attempt.
