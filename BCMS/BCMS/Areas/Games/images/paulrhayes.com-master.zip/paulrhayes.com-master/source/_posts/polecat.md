layout: photo
title: Polecat
date: 2014-06-25 17:42:13
flickr: https://www.flickr.com/photos/prhayes/14334597177/
instagram: http://instagram.com/p/pwYjakNFCv
500px: http://500px.com/photo/75799139/polecat-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/5.6"
shutter: "1/1000"
iso: 800

categories:
  - photography
---

From a wildlife photography lesson at the British Wildlife Centre in Sussex. This polecat was dancing about, very rarely stopping for anything. For a split second he raised his head in just the right position, the warm midsummer light catching his face amongst the flowers.
