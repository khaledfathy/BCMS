layout: photo
title: "Great Argus"
date: 2014-03-30 02:23:00
flickr: https://www.flickr.com/photos/prhayes/14252850944/
500px: http://500px.com/photo/76305381/great-argus-by-paul-hayes

exif: true
camera: "Canon EOS 500D"
lens: "Canon EF 70-200mm f/4L IS"
aperture: "ƒ/4.0"
shutter: "1/50"
iso: 1600
focal: "200.0mm"

categories:
  - photography
---

From our [trip to Danum Valley, Borneo](http://www.sam-and-paul.com/2014/05/borneo-rainforest-lodge/).

> In the clear­ing the Argus was tidy­ing away the dead leaves, prepar­ing a space to dance in, to impress and woo a female. The mat­ing call is beau­ti­fully sim­ple, a two-toned caw, unmis­take­able. For a won­der­ful 45 min­utes we stood and watched the bird, wait­ing and hop­ing that it might dance. A few times it looked like he was about to start, he ruf­fled his feath­ers and hopped, but then resumed tidy­ing. He had an audi­ence, just not the one he wanted, and despite his caws no female ever came. This was with­out doubt one of the most amaz­ing things either of us had ever seen, unforgettable.
