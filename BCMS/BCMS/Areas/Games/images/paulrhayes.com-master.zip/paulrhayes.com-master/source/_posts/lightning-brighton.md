layout: photo
title: "Stormy night in Brighton"
date: 2014-07-18 01:28:04
flickr: https://www.flickr.com/photos/prhayes/14682269822/
500px: http://500px.com/photo/76950797/stormy-night-in-brighton-by-paul-hayes
instagram: http://instagram.com/p/qli_Y4tFPh

exif: true
camera: "Canon EOS 70D"
lens: "Canon EF50mm f/1.4 USM"
aperture: "ƒ/18.0"
shutter: "30"
iso: 400
focal: "50.0mm"

categories:
  - photography
---

At 1am a feisty storm, the flashiest I’ve seen in Brighton, approached from the sea and passed directly overhead. I was lucky enough to capture this triple strike, which illuminated a ship between them.
