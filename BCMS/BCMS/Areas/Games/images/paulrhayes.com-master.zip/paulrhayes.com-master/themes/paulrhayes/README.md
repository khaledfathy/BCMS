# Paul R. Hayes Hexo theme

A port of the original [Wordpress theme](https://github.com/fofr/paulrhayes.com-wordpress)
